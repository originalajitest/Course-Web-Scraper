import discord
from discord.ext.commands import Bot
from selenium import webdriver
from selenium.webdriver.common.by import By
from prettytable import PrettyTable
# import time
import asyncio

# from datetime import datetime

# Bot token
TOKEN = 'MTEyODEwMjYzMzMxMjM3MDgzOA.GJDOSt.oAfDhJmEH7CiVzBmOP-eyzp0Zyw3uQ33-SiRrE'
invite = 'https://discord.com/api/oauth2/authorize?client_id=1128102633312370838&permissions=380104817664&scope=bot'
# Above is the link for the bot

intents = discord.Intents.default()
intents.messages = True
intents.message_content = True
intents.typing = False
intents.presences = False

# Create bot object
client = Bot(command_prefix="!", intents=intents)

# define a function that is run on the on_message event
bot_id = 1128102633312370838
me_id = 459744351715590173
channels = []
obj_links = []
admins = []
servers = []
url_check = 'https://courses.students.ubc.ca/cs/courseschedule?pname=subjarea&tname=subj-course&dept='
setup = False
tskip = 600
guilds = []

tab = PrettyTable(["Command", "Desc"])
tab.add_row(["!hello", "Greetings, what do you expect it to do lol."])
tab.add_row(["!help", "Opens this menu"])
tab.add_row(["!link", "Returns the invite link to add the bot to a server"])
tab.add_row(["!setup", "Allows a one time use of the !add-admin command by anyone. Can only be activated once"])
tab.add_row(["!ping", "Ping the specified UBC server after setting it up in the channel.\nCan only be run while the"
                      " bot is already running."])

tab2 = PrettyTable(["Admin Cmd", "Admin Cmd Desc"])
tab2.add_row(["!add-admin:@---", "Adds the mentioned user to the list of admins granting authority too run all\nadmin"
                                 " commands"])
tab2.add_row(["!status", "Check if it is possible to ping the server/run the bot"])
tab2.add_row(["!set-lab:---", "States if there are labs or discussions in the course referred to in the url.\nDefault"
                              " set to False"])
tab2.add_row(["!sec", "Returns the sections already in the sections list"])
tab2.add_row(["!set-sec:---", "Sets if there are specific sections to check for or not.\nDefault set to False"])
tab2.add_row(["!add-sec:---", "Takes the text to the right of colon and added it to sections to check. Space\n"
                              "sensitive (will check for space as part of the section)"])
tab2.add_row(["!rmv-sec:---", "Takes the text to the right of colon and removes it from sections to check.\nSpace"
                              " sensitive (will not be able to remove if not exact match with entry)"])
tab2.add_row(["!emt-sec", "Empties the List of sections"])

tab3 = PrettyTable(["Admin Cmd", "Admin Cmd Desc"])
tab3.add_row(["!set-url:---", "Sets the ping url to specified url. Space sensitive (no spaces).\nTo specify the"
                              " Okanagan campus add &campuscd=UBCO to the end of the url.\nWill not work with url's"
                              " outside of ubc."])
tab3.add_row(["!set-role:@---", "Takes the first role mentioned and sets it to ping given role when the course\ngets"
                                " some space"])
tab3.add_row(["!restricted:---", "Sets whether to include when given course has restricted space.\nDefault set to"
                                 " False"])
tab3.add_row(["!waitlist:---", "Sets it the program should return waitlists for courses.\nDefault set to False"])
tab3.add_row(["!run", "Runs the bot. It will ping the server again after 10 mins have passed until\nthere is space or"
                      " the bot is stopped."])
tab3.add_row(["!stop", "Stops the bot"])


@client.event
async def on_ready():
    print("Bot Running")
    print(f'Logged in as {client.user.name} ({client.user.id})')
    global guilds
    for guild in client.guilds:
        guilds.append(guild)
        await guild.text_channels[0].send("Please set up the bot again, it went down for maintainance")


@client.event
async def on_guild_join(guild):
    global guilds
    guilds.append(guild)
    await guild.text_channels[0].send("Hello, this is a bot designed to scrap course information and availability"
                                      " from its website.\nIn order to use, first you need to set the url to the"
                                      " desired location, then give the bot a role which it should ping when there is"
                                      " availability.\nYou should further specify if there are labs or dscussions"
                                      " included on the page.\nYou can further specify which sections to checks so that"
                                      " you do not recieve a ping for each open space.\nThen you just need to run the"
                                      " !run command to start the bot\nCurrently the bot is configured to run itself"
                                      " every 10 minutes, in order to propose changes please get in contact with the"
                                      " bot creator.\nYou can run a different instance of the bot in a separate channel"
                                      " hence allowing for multiple course scrappers."
                                      "\nTo find the runable commands run !help.\nMost commands require you to be an"
                                      " admin for the bot to run, check !help.")
    print(f"Bot added to {guild}")


@client.event
async def on_guild_remove(guild):
    global guilds
    guilds.remove(guild)
    print(f"Bot was removed from server: {guild}")


@client.event
async def on_message(message):
    if message.author.bot:
        return
    bypass = False
    if message.author.id == me_id:
        bypass = True
    channel = message.channel.id
    msg = message.content.lower()

    global channels, obj_links, servers, setup, guilds

    if channels.__contains__(channel):
        place = channels.index(channel)
    else:
        print(f"created instance for channel ({channel})")
        channels.append(channel)
        place = channels.index(channel)
        obj_links.append(Scrapper(channel))
    obj = obj_links.__getitem__(place)
    # await message.channel.send(f"<@{message.author.id}>")
    # await message.channel.send(f"@everyone")
    # Testing how to ping a role instead of everyone below msg does the same
    # await message.channel.send(message.content)

    if msg[:1] == "!":
        if bypass:
            if "!!!time:" == msg[:8]:
                global tskip
                tskip = int(msg[8:])
                print("Time loop changed to: ")
                await message.reply("Rest time set to: " + str(tskip))
            elif "!!!rmv:" == msg[:7]:
                if admins.__contains__(message.mentions[0].id):
                    admins.remove(message.mentions[0].id)
                    print(f"{message.mentions[0].name} ({message.mentions[0].id}) has been removed from admin list.")
            elif "!!!broadcast:" == msg[:13]:
                for guild in guilds:
                    await guild.text_channels[0].send("Message from admin >>>\n" + message.content[13:])
                    await message.channel.send(f"Message sent to server: {guild.name} ({guild.id})")
            elif "!!!flush" == msg:
                channels = []
                obj_links = []
                servers = []
                setup = False
                guilds = []

        if "!hello" == msg:
            await message.reply("Greetings " + message.author.nick + ".")

        elif "!link" == msg:
            await message.reply(invite)

        elif "!help" == msg:
            tab_str = "```\n" + tab.get_string() + "\n```"
            tab2_str = "```\n" + tab2.get_string() + "\n```"
            tab3_str = "```\n" + tab3.get_string() + "\n```"
            await message.channel.send(tab_str)
            await message.channel.send(tab2_str)
            await message.channel.send(tab3_str)

        elif "!setup" == msg:
            if servers.__contains__(message.guild.id):
                await message.channel.send("This is not a new server, ask a current admin to add privileges for you.")
            else:
                setup = True
                await message.channel.send("The !add-admin:@--- command is allowed for a one time use by anyone.")

        elif "!ping" == msg:
            if obj.running:
                await _once_(obj, message)

        elif "!add-admin:" == msg[:11]:
            if setup:
                admin = False
                for user in message.mentions:
                    if not admins.__contains__(user.id):
                        admins.append(user.id)
                        user_name = user.name
                        await message.channel.send(f"<@{user.id}> added to admins.")
                        print(user_name + " added to admins")
                        admin = True
                if admin:
                    setup = False
            elif admins.__contains__(message.author.id) or bypass:
                for user in message.mentions:
                    if not admins.__contains__(user.id):
                        admins.append(user.id)
                        user_name = user.name
                        await message.channel.send(f"<@{user.id}> added to admins.")
                        print(user_name + " added to admins")
            else:
                await message.reply("You do not have sufficient permissions")

        elif admins.__contains__(message.author.id) or bypass:
            if "!status" == msg:
                if obj.cur_status():
                    await message.channel.send("Required fields filled")
                else:
                    await message.channel.send("Not Ready")

            elif "!set-url:" == msg[:9]:
                # To get into the okanagan website add &campuscd=UBCO. like wise for the van website &campuscd=UBC
                if url_check in msg[9:97]:
                    await message.channel.send("UBC course url found")
                    obj.set_url(message.content[9:])
                    await message.channel.send("URL set to: " + obj.url)
                else:
                    await message.channel.send("This bot only supports UBC courses as of now, or the input is in an "
                                               "incorrect format. An example input would be: !set-url:"
                                               "https://courses.students.ubc.ca/cs/courseschedule?pname=subjarea&tname="
                                               "subj-course&dept=MATH&course=100)\nNot this only works with course"
                                               " overview not a specific section. Please do not insert spaces.")

            elif "!set-lab:" == msg[:9]:
                if "false" in msg:
                    obj.set_lab(False)
                    await message.channel.send("Labs/Discussions: False")
                elif "true" in msg:
                    obj.set_lab(True)
                    await message.channel.send("Labs/Discussions: True")
                else:
                    await message.channel.send("Invalid input")

            elif "!sec" == msg:
                await message.channel.send(obj.sections)

            elif "!set-sec:" == msg[:9]:
                if "false" in msg:
                    obj.set_sec(False)
                    await message.channel.send("Specific Sections: False")
                elif "true" in msg:
                    obj.set_sec(True)
                    await message.channel.send("Specific Sections: True")
                else:
                    await message.channel.send("Invalid input")

            elif "!add-sec:" == msg[:9]:
                obj.add_sec(message.content[9:])
                await message.channel.send(msg[9:] + " added to included sections")

            elif "!rmv-sec:" == msg[:9]:
                if obj.rmv_sec(message.content[9:]):
                    await message.channel.send(msg[9:] + " removed from included sections")
                else:
                    await message.channel.send(msg[9:] + " section does not exist in list")

            elif "!emt-sec" == msg[:8]:
                obj.emt_sec()
                await message.channel.send("Sections list has been emptied")

            elif "!set-role:" == msg[:10]:
                obj.set_role(message.role_mentions[0])
                await message.channel.send("Role ping changed to: " + str(obj.role))

            elif "!restricted:" == msg[:12]:
                if "false" in msg:
                    obj.set_restricted(False)
                    await message.channel.send("Return Restricted: False")
                elif "true" in msg:
                    obj.set_restricted(True)
                    await message.channel.send("Return Restricted: True")
                else:
                    await message.channel.send("Invalid input")

            elif "!waitlist:" == msg[:10]:
                if "false" in msg:
                    obj.set_waitlist(True)
                    await message.channel.send("Waitlists: False")
                elif "true" in msg:
                    obj.set_waitlist(False)
                    await message.channel.send("Waitlists: True")
                else:
                    await message.channel.send("Invalid input")

            elif "!run" == msg:
                if obj.cur_status():
                    obj.running = True
                    await _main_(obj, message)

            elif "!stop" == msg:
                obj.running = False
        else:
            await message.channel.reply("This Command does not exist or you do not have sufficient privileges.")


async def _once_(obj, message):
    obj.__main__()
    obj.rmv_n_fill()
    if obj.empty():
        await message.channel.send("No changes to course.")
        print("No change to course " + str(obj.role))
    else:
        await ping(obj, message)
        i = 0
        t = PrettyTable(["Status", "Course", "Link"])
        for space in obj.status:
            t.add_row([space, obj.course[i], obj.links[i]])
            i += 1
        await message.channel.send(t)


async def _main_(obj, message):
    while obj.running:
        obj.__main__()
        obj.rmv_n_fill()
        if obj.empty():
            await message.channel.send("No changes to course.")
            print("No change to course: " + str(obj.role))
        else:
            await ping(obj, message)
            i = 0
            t = PrettyTable(["Status", "Course", "Link"])
            for space in obj.status:
                t.add_row([space, obj.course[i], obj.links[i]])
                i += 1
            await message.channel.send(t)
            obj.running = False
        if obj.running:
            await asyncio.sleep(tskip)
            # change this to change frequency of pings


async def ping(obj, message):
    role = discord.utils.get(message.guild.roles, name=str(obj.role))
    print("Role: " + str(role) + ". Pinged on update to course. Loop stopped, restart required.")
    if role:
        await message.channel.send(f'{role.mention}')


# how to send a msg
# await message.channel.send("One msg (message.content)" + message.content)

# Web Scrapping code, copied to not have multiple files.


class Scrapper(object):
    chan = 0
    url = ''
    labs = False
    specific = False
    sections = []
    ready = False
    keep_restricted = False
    role = ''
    running = False
    waitlist = True
    ubco = False

    status = []
    course = []
    links = []

    def __init__(self, channel):
        self.chan = channel
        self.url = ''
        self.labs = False
        self.specific = False
        self.sections = []
        self.ready = False
        self.keep_restricted = False
        self.role = ''
        self.running = False

        self.status = []
        self.course = []
        self.links = []

    def cur_status(self):
        if not len(self.url) == 0:
            if not len(str(self.role)) == 0:
                if self.specific:
                    self.ready = not (len(self.sections) == 0)
                    return self.ready
                self.ready = True
                return self.ready
        self.ready = False
        return self.ready

    def set_url(self, inp):
        self.url = inp
        if "&campuscd=UBCO" in inp:
            self.ubco = True
        print("Set the url to: " + inp)

    def set_lab(self, inp):
        self.labs = inp
        print("Set labs to: " + str(inp))

    def set_sec(self, inp):
        self.specific = inp
        print("Set specifications to: " + str(inp))

    def add_sec(self, inp):
        self.sections.append(inp)
        print("Added section: " + inp)

    def rmv_sec(self, inp):
        if self.sections.__contains__(inp):
            self.sections.remove(inp)
            print("Removed section: " + inp)
            return True
        else:
            return False

    def emt_sec(self):
        self.sections.clear()
        print("Sections list has been emptied")

    def set_restricted(self, inp):
        self.keep_restricted = inp
        print("Return Restricted: " + str(inp))

    def set_role(self, inp):
        self.role = inp
        print("Role ping changed to: " + str(inp))

    def set_waitlist(self, inp):
        self.waitlist = inp
        print("Waitlist changed to: " + str(inp))

    # Scrapper code
    def __main__(self):
        self.status = []
        self.course = []
        self.links = []

        driver = webdriver.Chrome()
        driver.implicitly_wait(1)
        driver.get(self.url)

        # section1 = lec
        # section2 = labs || discussions
        # a waitList can be either. All waitlists are removed by default.
        # in the event there are no labs|discussions, section2 is another lec
        if self.labs:
            l = driver.find_elements(By.CLASS_NAME, 'section1')
        else:
            l1 = driver.find_elements(By.CLASS_NAME, 'section1')
            l2 = driver.find_elements(By.CLASS_NAME, 'section2')
            l = []
            no_last = False
            if len(l1) == len(l2):
                no_last = True
            for i in range(0, len(l2)):
                l.append(l1[i])
                l.append(l2[i])
            if not no_last:
                l.append(l1[-1])

        i = 0
        while self.waitlist:
            if i >= len(l):
                break
            if "Waiting List" in str(l[i]):
                l.remove(l[i])
                i -= 1
            i += 1

        found = False

        if self.specific:
            # Had to remove another for loop cause it was breaking my code :(
            i = 0
            while True:
                if i >= len(l):
                    break
                data = l[i].get_attribute('innerHTML')
                for section in self.sections:
                    if section in data:
                        found = True
                        break
                if not found:
                    l.remove(l[i])
                    i -= 1
                found = False
                i += 1

        for item in l:
            data = item.get_attribute('innerHTML')
            split = data.split('</td>')
            if ' ' in split[0].split('>')[1]:
                self.status.append('Space')
            else:
                self.status.append(split[0].split('>')[1])
            self.course.append(split[1].split('">')[1].split('</')[0])
            temp = 'https://courses.students.ubc.ca' + split[1].split('">')[0].split('"')[1]
            link = ''
            for part in temp.split('amp;'):
                link = link + part
            if self.ubco:
                link = link + "&campuscd=UBCO"
            else:
                link = link + "&campuscd=UBC"
            self.links.append(link)

    def rmv_n_fill(self):
        if not self.empty():
            # for loops use lists so the direct manipulation of vars not good, while is better. Change
            # range(0,5) returns a list of [0,1,2,3,4,5] so the i manipulation changes the int at i index, we never
            # check that int again making that code useless.
            i = 0
            while True:
                if i >= len(self.status):
                    break
                if self.keep_restricted:
                    if not (('Space' == self.status[i]) or ('Restricted' == self.status[i])):
                        self.status.remove(self.status[i])
                        self.course.remove(self.course[i])
                        self.links.remove(self.links[i])
                        i -= 1
                else:
                    if not ('Space' == self.status[i]):
                        self.status.remove(self.status[i])
                        self.course.remove(self.course[i])
                        self.links.remove(self.links[i])
                        i -= 1
                i += 1

    def empty(self):
        if len(self.status) == 0:
            return True
        else:
            return False


client.run(TOKEN)
